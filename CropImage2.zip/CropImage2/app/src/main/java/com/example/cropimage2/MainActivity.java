package com.example.cropimage2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    private CircleImageView ProfilResmi;

    private Button resimekle;
    private static int GaleriSecme=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

ProfilResmi=findViewById(R.id.profil_resmi);
resimekle=findViewById(R.id.resimekle);




ProfilResmi.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent galeriIntent=new Intent();
        galeriIntent.setAction(Intent.ACTION_GET_CONTENT);
        galeriIntent.setType("image/*");
        startActivityForResult(galeriIntent,GaleriSecme);



    }
});




    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Uri ResimUri=data.getData();
//        CropImage.activity()
//                .setDuidelines(CropImage.Guidelines.ON)
//                .setAspectRatio(1,1)
//                .start(this);
    }
}